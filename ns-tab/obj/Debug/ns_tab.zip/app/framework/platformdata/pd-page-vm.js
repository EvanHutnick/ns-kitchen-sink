var observable = require("data/observable");            // observable, because viewmodel

exports.platformdataViewModel = new observable.Observable();
exports.platformdataViewModel.set("demoItems", []);



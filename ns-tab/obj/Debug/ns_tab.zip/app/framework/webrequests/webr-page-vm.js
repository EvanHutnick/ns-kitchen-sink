var observable = require("data/observable");            // observable, because viewmodel

exports.webrViewModel = new observable.Observable();
exports.webrViewModel.set("sendText", "");



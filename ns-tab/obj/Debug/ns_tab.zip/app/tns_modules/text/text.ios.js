var encoding;
(function (encoding) {
    encoding.ISO_8859_1 = 5;
    encoding.US_ASCII = 1;
    encoding.UTF_16 = 10;
    encoding.UTF_16BE = 0x90000100;
    encoding.UTF_16LE = 0x94000100;
    encoding.UTF_8 = 4;
})(encoding = exports.encoding || (exports.encoding = {}));

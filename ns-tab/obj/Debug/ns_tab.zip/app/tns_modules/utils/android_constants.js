exports.btn_default = 0x01080004;
exports.state_first = 0x010100a4;
exports.state_enabled = 0x0101009e;
exports.state_pressed = 0x010100a7;
exports.state_selected = 0x010100a1;
exports.state_single = 0x010100a3;
exports.state_hovered = 0x01010367;
exports.state_focused = 0x0101009c;
